package com.example.registration

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val pre = this.getSharedPreferences("user", MODE_PRIVATE)

        val auth = FirebaseAuth.getInstance()

        val etEmail = findViewById<TextInputEditText>(R.id.etSEmailAddress)
        val etConfPass = findViewById<TextInputEditText>(R.id.etSConfPassword)
        val etPass = findViewById<TextInputEditText>(R.id.etSPassword)
        val Address = findViewById<TextInputEditText>(R.id.address)
        val Age = findViewById<TextInputEditText>(R.id.age)
        val Name = findViewById<TextInputEditText>(R.id.name)


        val tvRedirectLogin = findViewById<TextView>(R.id.tvRedirectLogin)
        tvRedirectLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        val btnSignUp = findViewById<Button>(R.id.btnSSigned)
        btnSignUp.setOnClickListener {

            val email = etEmail.text.toString()
            val pass = etPass.text.toString()
            val confirmPassword = etConfPass.text.toString()

            val address = Address.text.toString()
            val age = Age.text.toString()
            val name = Name.text.toString()


            val add = HashMap<String, Any>()
            add["Address"] = address
            add["Age"] = age
            add["Name"] = name


            if (pass != confirmPassword) {
                Toast.makeText(
                    this,
                    "Password and Confirm Password do not match",
                    Toast.LENGTH_SHORT
                ).show()
            } else if (email.isNotEmpty() || pass.isNotEmpty() || confirmPassword.isNotEmpty()) {
                auth.createUserWithEmailAndPassword(email, pass)

                    .addOnSuccessListener {
                        Firebase.firestore.collection("User").document(it.user!!.uid).set(add)

                        pre.edit().putString("currentUserId", it.user?.uid).apply()
                        startActivity(Intent(this, Homepage::class.java))
                        finish()

                        Toast.makeText(this, "Successfully Singed Up", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Singed Up Failed!", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Please fill all field", Toast.LENGTH_SHORT).show()
            }
        }


    }

}

