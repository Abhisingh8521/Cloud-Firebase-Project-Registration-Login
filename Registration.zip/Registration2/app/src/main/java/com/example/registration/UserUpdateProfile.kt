package com.example.registration

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class UserUpdateProfile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_update_profile)

        val updatename=findViewById<TextInputEditText>(R.id.userUPdateName)
        val updateaddress=findViewById<TextInputEditText>(R.id.userUPdateaddress)
        val updateage=findViewById<TextInputEditText>(R.id.userUPdateage)
        val updatebtn=findViewById<Button>(R.id.btnUpdate)

        val updateUserid=Firebase.auth.currentUser?.uid
        Firebase.firestore.collection("User").document(updateUserid!!).get()
            .addOnSuccessListener {
                updatename.setText(it.data?.get("Name").toString())
                updateage.setText(it.data?.get("Age").toString())
                updateaddress.setText(it.data?.get("Address").toString())
                    updatebtn.setOnClickListener {

                        val hashMap= hashMapOf<String,Any>()
                        hashMap["Address"] = updateaddress.text.toString()
                        hashMap["Age"] = updateage.text.toString()
                        hashMap["Name"] = updatename.text.toString()

                        Firebase.firestore.collection("User").document(updateUserid).set(hashMap)
                            .addOnSuccessListener {
                                Toast.makeText(this, "Success Update", Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this,Homepage::class.java))
                                finish()
                            }
                    }

            }
            }

    }
