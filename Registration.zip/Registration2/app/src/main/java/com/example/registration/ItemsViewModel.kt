package com.example.registration

data class ItemsViewModel(
    val image: Int,
    val text: String? = null,
    val Prize: Int
)

