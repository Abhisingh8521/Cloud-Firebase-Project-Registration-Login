package com.example.registration

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class ProfileFragment : Fragment() {


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val userId = Firebase.auth.currentUser?.uid

        Firebase.firestore.collection("User").document(userId!!).get()
            .addOnSuccessListener {
                val village = it.data?.get("Address").toString()
                val age = it.data?.get("Age").toString()
                val name = it.data?.get("Name").toString()
                view.findViewById<TextView>(R.id.villageid).text = village
                view.findViewById<TextView>(R.id.nameid).text=name
                view.findViewById<TextView>(R.id.ageid).text=age

            }
            .addOnFailureListener {
                Toast.makeText(context, "Fail", Toast.LENGTH_SHORT).show()
            }
        val profoleupdate=view.findViewById<Button>(R.id.updateProfileUser)
        profoleupdate.setOnClickListener {
            startActivity(Intent(context,UserUpdateProfile::class.java))
            requireActivity().finish()

        }

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_profile, container, false)
    }


}
