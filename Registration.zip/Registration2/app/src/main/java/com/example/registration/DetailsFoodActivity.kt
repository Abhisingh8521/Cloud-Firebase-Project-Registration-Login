package com.example.registration

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailsFoodActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details_food)
        val imageView=findViewById<ImageView>(R.id.userImage)
        val text1=findViewById<TextView>(R.id.userProducr)
        val text2=findViewById<TextView>(R.id.userPrize)
      val image=intent.getIntExtra("image",0)
      val name=intent.getStringExtra("text")
      val prize=intent.getIntExtra("prize",0)
        imageView.setImageResource(image)
        text1.text = name
        text2.text = prize.toString()
    }
}