package com.example.registration

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class CustomAdapter(private val mList: List<ItemsViewModel>, private val setOnclick:onClickListener) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageview)
        val textView: TextView = itemView.findViewById(R.id.textView)
        val prize: TextView = itemView.findViewById(R.id.prize)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.card_view_design, parent, false)
        return ViewHolder(view)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val ItemsViewModel = mList[position]

        ItemsViewModel.image?.let { holder.imageView.setImageResource(it) }
        holder.textView.text = ItemsViewModel.text
        holder.prize.text = ItemsViewModel.Prize.toString()
        holder.itemView.setOnClickListener {
            setOnclick.onClick(position,ItemsViewModel)
        }

    }

    override fun getItemCount(): Int {
        return mList.size
    }


}
interface onClickListener {
    fun onClick(position: Int, itemsViewModel: ItemsViewModel)
}
